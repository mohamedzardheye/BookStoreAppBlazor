﻿
namespace BookStoreApp.Blazor.Server.Services.Base
{


    public partial interface IClient
    {
        public HttpClient HttpClient { get; }
    }



}

