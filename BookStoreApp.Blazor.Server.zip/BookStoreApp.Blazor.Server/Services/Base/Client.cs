﻿
namespace BookStoreApp.Blazor.Server.Services.Base
{


    public partial class Client : IClient
    {
        public HttpClient HttpClient
        {
            get
            {
                return _httpClient;
            }
        }
    }


}
